var healthfreetime = true;
var healthText; 
var scoreText; 
var player;
var stars;
var bombs;
var platforms;
var cursors;
var score = 0;
var gameOver = false;
var scoreText;
var enemy;
var check_enemy = [false, false, false, false, false, false, false, false, false];
var health = 5;
var startime = Math.floor(performance.now()/1000);
var checker = true; 
var ostartime;
var hstartime;
var time_dmg = [0, 0, 0, 0, 0, 0, 0, 0, 0];

class Lvl1 extends Phaser.Scene{

	constructor(){
		super("Level1")
	}

	preload ()
	{

		this.load.bitmapFont('font', 'assets/font/font_0.png', 'assets/font/font.fnt');

		this.load.image('enemy1', 'assets/enemy1.png');
		
		this.load.image('level', 'assets/leveldesign/lvl1Base.png');
		
	}

	create ()
	{
		
		this.cameras.main.fadeIn(1500);

		var config = this.game.config;

		//  A simple background for our game
		this.add.image(0, 0,'level').setOrigin(0).setDisplaySize(config.width,config.height);

		//Health and Score in bitmap Text
		this.healthText = this.add.bitmapText(10,25,'font', 'HEALTH: ' + health, 32);
		this.scoreText =  this.add.bitmapText(10,65,'font', 'SCORE: ' + score, 32);

		//this.enemy = this.physics.add.staticGroup();
		//coordinates of platform 1 620, 180
		//setup enemies and setup coordinates by the display size
		this.enemy1 = this.add.sprite((config.width/3)-45, config.height/3,'enemy1').setScale(1);
		this.enemy1.visible = false;
		this.enemy2 = this.add.sprite(config.width/2, config.height/3, 'enemy1').setScale(1);
		this.enemy2.visible = false;
		this.enemy3 = this.add.sprite(config.width-550, config.height/3, 'enemy1').setScale(1);
		this.enemy3.visible = false;
		this.enemy4 = this.add.sprite((config.width/3)-45, config.height/2, 'enemy1').setScale(1);
		this.enemy4.visible = false;
		this.enemy5 = this.add.sprite(config.width/2,config.height/2, 'enemy1').setScale(1);
		this.enemy5.visible = false;
		this.enemy6 = this.add.sprite(config.width-550, config.height/2, 'enemy1').setScale(1);
		this.enemy6.visible = false;
		this.enemy7 = this.add.sprite((config.width/3)-45, config.height-275, 'enemy1').setScale(1);
		this.enemy7.visible = false;
		this.enemy8 = this.add.sprite(config.width/2, config.height-275, 'enemy1').setScale(1);
		this.enemy8.visible = false;
		this.enemy9 = this.add.sprite(config.width-550, config.height-275, 'enemy1').setScale(1);
		this.enemy9.visible = false;

		cursors = this.input.keyboard.createCursorKeys();
		//this.input.keyboard.on('keydown_W', this.your this);
		//  Some stars to collect, 12 in total, evenly spaced 70 pixels apart along the x axis
		this.scene.resume();

	}
	/*
	//measures time elapsed in ms
	//invincibility frame tracker (so that the user doesnt instantly kill themselves due to pressing a button too much)
	healthfreetime = true;
	ostartime;
	//with the way phaser.io works with update it checks update approx >50 times per second so we must give the user some invincibility frames 
	hstartime = startime;
	//for now if this.enemy is alive for more then 3 seconds you take dmg then the this.enemy disappears
	//score/money tracker, lvl 1 mobs will all give 10 score/money
	*/

	update ()
	{
		var keyObj1 = this.input.keyboard.addKey('NUMPAD_SEVEN');
		var keyObj2 = this.input.keyboard.addKey('NUMPAD_EIGHT');
		var keyObj3 = this.input.keyboard.addKey('NUMPAD_NINE');
		var keyObj4 = this.input.keyboard.addKey('NUMPAD_FOUR');
		var keyObj5 = this.input.keyboard.addKey('NUMPAD_FIVE');
		var keyObj6 = this.input.keyboard.addKey('NUMPAD_SIX');
		var keyObj7 = this.input.keyboard.addKey('NUMPAD_ONE');
		var keyObj8 = this.input.keyboard.addKey('NUMPAD_TWO');
		var keyObj9 = this.input.keyboard.addKey('NUMPAD_THREE');
		//console.log(Math.floor((Math.random() * 9) + 1));
		//check if 5 seconds have passed if so then spawn a monster! (update startime in here to current time if u get in here)
		if(health > 0)
		{
		//MONSTER GENERATION	
		if(startime + 5 == Math.floor(performance.now()/1000) && checker && !(check_enemy[0] && check_enemy[1] && check_enemy[2] && check_enemy[3] && check_enemy[4] && check_enemy[5] && check_enemy[6] && check_enemy[7] && check_enemy[8]))
		{
			//pick a tile first 
			let tile = Math.floor((Math.random() * 9) + 1);
			let tile2 = Math.floor((Math.random() * 9) + 1);
			//console.log(tile);
			//check to see if theres something there if there is then pick a different tile
			while(check_enemy[tile - 1] && tile != tile2 && check_enemy[tile2 - 1])
			{
				tile = Math.floor((Math.random() * 9) + 1);
				tile2 = Math.floor((Math.random() * 9) + 1);
				//console.log(tile);
			}
			console.log(tile);
			console.log(tile2);
			//add if statements for different tiles(the above while statement guarantees that two tiles won't be equal)
			if(tile == 1 || tile2 == 1)
			{
				this.enemy1.visible = true;
				check_enemy[0] = true;
				time_dmg[0] = Math.floor(performance.now()/1000);
				console.log("hi");
			}
			if(tile == 2 || tile2 == 2)
			{
				this.enemy2.visible = true;
				check_enemy[1] = true;		
				time_dmg[1] = Math.floor(performance.now()/1000);
			}
			if(tile == 3 || tile2 == 3)
			{
				this.enemy3.visible = true;
				check_enemy[2] = true;
				time_dmg[2] = Math.floor(performance.now()/1000);
			}
			if(tile == 4 || tile2 == 4)
			{
				this.enemy4.visible = true;
				check_enemy[3] = true;
				time_dmg[3] = Math.floor(performance.now()/1000);
			}
			if(tile == 5 || tile2 == 5)
			{
				this.enemy5.visible = true;
				check_enemy[4] = true;	
				time_dmg[4] = Math.floor(performance.now()/1000);
			}
			if(tile == 6 || tile2 == 6)
			{
				this.enemy6.visible = true;
				check_enemy[5] = true;
				time_dmg[5] = Math.floor(performance.now()/1000);
			}
			if(tile == 7 || tile2 == 7)
			{
				this.enemy7.visible = true;
				check_enemy[6] = true;
				time_dmg[6] = Math.floor(performance.now()/1000);
			}
			if(tile == 8 || tile2 == 8)
			{
				this.enemy8.visible = true;
				check_enemy[7] = true;
				time_dmg[7] = Math.floor(performance.now()/1000);
			}
			if(tile == 9 || tile2 == 9)
			{
				this.enemy9.visible = true;
				check_enemy[8] = true;
				time_dmg[8] = Math.floor(performance.now()/1000);
				console.log("tile9");
			}
			checker = false;
			ostartime = startime;
			startime = Math.floor(performance.now()/1000);
		}
		//had to add this to make sure it didnt update like 40 times 
		if(ostartime + 6 == Math.floor(performance.now()/1000))
		{
			checker = true;
		}
		if(hstartime + 2 <= Math.floor(performance.now()/1000))
		{
			healthfreetime = true;
			
		}
		//USER INPUTTING
		if(keyObj1.isDown && check_enemy[0])
		{
			time_dmg[0] = 0;
			check_enemy[0] = false;		
			this.enemy1.visible = false;
			healthfreetime = false;
			//original did - 1 for invincibility time for getting the right press but if the user held the key even slightly then it would deduct a health so changed to .5 to give slightly more time
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
			}
		else if(keyObj1.isDown && healthfreetime)
		{
			health--;			
			this.healthText.text = "HEALTH: " + health;
		
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);		 
		}
		if(keyObj2.isDown && check_enemy[1])
		{
			time_dmg[1] = 0;
			check_enemy[1] = false;		
			this.enemy2.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
			}
		else if(keyObj2.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
			
		}
		if(keyObj3.isDown && check_enemy[2])
		{
			time_dmg[2] = 0;
			check_enemy[2] = false;		
			this.enemy3.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
		}
			else if(keyObj3.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
		}
		if(keyObj4.isDown && check_enemy[3])
		{
			time_dmg[3] = 0;
			check_enemy[3] = false;		
			this.enemy4.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
		} 
		else if(keyObj4.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
			
		}
		if(keyObj5.isDown && check_enemy[4])
		{
			time_dmg[4] = 0;
			check_enemy[4] = false;		
			this.enemy5.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
		}
		else if(keyObj5.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
			
		}
		if(keyObj6.isDown && check_enemy[5])
		{
			time_dmg[5] = 0;
			check_enemy[5] = false;		
			this.enemy6.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
		}
		else if(keyObj6.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
			
		}
		if(keyObj7.isDown && check_enemy[6])
		{
			time_dmg[6] = 0;
			check_enemy[6] = false;		
			this.enemy7.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
		}
		else if(keyObj7.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
			
		}
		if(keyObj8.isDown && check_enemy[7])
		{
			time_dmg[7] = 0;
			check_enemy[7] = false;		
			this.enemy8.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
		} 
		else if(keyObj8.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
			
		}
		if(keyObj9.isDown && check_enemy[8])
		{
			time_dmg[8] = 0;
			check_enemy[8] = false;		
			this.enemy9.visible = false;
			healthfreetime = false;
			hstartime = Math.floor(performance.now()/1000) - .5;
			score = score + 10;
			this.scoreText.text = "SCORE: " + score;
		}
		else if(keyObj9.isDown && healthfreetime)
		{
			health--;
			this.healthText.text - "HEALTH" + health;
			healthfreetime = false;		
			hstartime = Math.floor(performance.now()/1000);
			
		}
		//MONSTER DETECTION(if a monster is up for too long u take dmg and monster leaves)
		//no invincibility frames for this part if u miss an this.enemy
		if(((time_dmg[0] + 3) < Math.floor(performance.now()/1000)) && time_dmg[0] != 0)
		{
			check_enemy[0] = false;
			this.enemy1.visible = false;
			time_dmg[0] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		//missing multiple enemies will dmg you for each one you miss (might change this later based on balanced decisions of play through tests)
		if(((time_dmg[1] + 3) < Math.floor(performance.now()/1000)) && time_dmg[1] != 0)
		{
			check_enemy[1] = false;
			this.enemy2.visible = false;
			time_dmg[1] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		if(((time_dmg[2] + 3) < Math.floor(performance.now()/1000)) && time_dmg[2] != 0)
		{
			check_enemy[2] = false;
			this.enemy3.visible = false;
			time_dmg[2] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		if(((time_dmg[3] + 3) < Math.floor(performance.now()/1000)) && time_dmg[3] != 0)
		{
			check_enemy[3] = false;
			this.enemy4.visible = false;
			time_dmg[3] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		if(((time_dmg[4] + 3) < Math.floor(performance.now()/1000)) && time_dmg[4] != 0)
		{
			check_enemy[4] = false;
			this.enemy5.visible = false;
			time_dmg[4] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		if(((time_dmg[5] + 3) < Math.floor(performance.now()/1000)) && time_dmg[5] != 0)
		{
			check_enemy[5] = false;
			this.enemy6.visible = false;
			time_dmg[5] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		if(((time_dmg[6] + 3) < Math.floor(performance.now()/1000)) && time_dmg[6] != 0)
		{
			check_enemy[6] = false;
			this.enemy7.visible = false;
			time_dmg[6] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		if(((time_dmg[7] + 3) < Math.floor(performance.now()/1000)) && time_dmg[7] != 0)
		{
			check_enemy[7] = false;
			this.enemy8.visible = false;
			time_dmg[7] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		if(((time_dmg[8] + 3) < Math.floor(performance.now()/1000)) && time_dmg[8] != 0)
		{
			check_enemy[8] = false;
			this.enemy9.visible = false;
			time_dmg[8] = 0;
			health--;
			this.healthText.text = "HEALTH: " + health;
				
			}
		
		}
		else{
			health = 5;
			score = 0; 
			this.scene.restart();
		}
	}

}


window.onload = function() {

    var config = {
        type: Phaser.AUTO,
        width: window.innerWidth,
        height: window.innerHeight, 
        scene: [Tutorial, Lvl1],
        physics: {
            default: 'arcade',
            arcade: {
                gravity: { y: 300 },
                debug: false
            }
        },
       
    }
    var game = new Phaser.Game(config)

}

